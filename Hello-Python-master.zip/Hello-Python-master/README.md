# Data Analysis with pandas

Basic introduction to the usage of pandas as programable replacement of a graphical spreadsheet.

##  Launch in executable environment

Click on the "launch binder" button below to open those notebooks in an executable environment. Start with the [index.ipynb notebook](./index.ipynb) and follow the others from there.

[![Binder](https://mybinder.org/badge.svg)](https://mybinder.org/v2/gh/restrepo/data-analysis/master)

Shorten URL [http://bit.ly/analisisdedatosudea](http://bit.ly/analisisdedatosudea
)



